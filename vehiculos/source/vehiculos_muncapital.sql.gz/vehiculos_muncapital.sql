-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-05-2019 a las 00:13:48
-- Versión del servidor: 10.1.31-MariaDB
-- Versión de PHP: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `vehiculos_muncapital`
--

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `001_documentaciones`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `001_documentaciones` (
`documentacion_id` varchar(10)
,`documentacion_tmp_iniciador` varchar(100)
,`documentacion_tmp_asunto` text
,`documentacion_tmp_SYSusuario` varchar(20)
,`documentacion_tmp_estado` char(1)
,`documentacion_tipo_id` varchar(5)
,`documentacion_tipo_otro` varchar(50)
,`documentacion_numero` int(10)
,`documentacion_numero_ano` int(4)
,`documentacion_numero_documentacion_tipo_id` varchar(5)
,`documentacion_organismo_area_id` varchar(5)
,`iniciador_tipo` char(1)
,`iniciador_persona_id` varchar(5)
,`iniciador_organismo_id` varchar(10)
,`iniciador_organismo_area_id` varchar(5)
,`iniciador_otro` varchar(100)
,`expediente_numero` int(5)
,`expediente_codigo` int(3)
,`expediente_ano` int(4)
,`expediente_fecha` date
,`expediente_SYSusuario` varchar(20)
,`expediente_estado` char(1)
,`expediente_estado_suspendido_hasta` date
,`expediente_estado_suspendido_hasta_SYSusuario` varchar(20)
,`documentacion_asunto` text
,`documentacion_asunto_tipo_id` varchar(5)
,`documentacion_asunto_tipo_otro` varchar(50)
,`documentacion_fecha_inicio` date
,`documentacion_fecha` date
,`documentacion_hora` time
,`documentacion_folios` int(6)
,`documentacion_SYSusuario` varchar(20)
,`glosado_a_documentacion_id` varchar(10)
,`glosados` text
,`_alta_id` varchar(27)
,`seguimiento_id` varchar(10)
,`referencia_de_busqueda` varchar(20)
,`marca_fecha` date
,`marca_hora` time
,`marca_SYSusuario` char(20)
,`marca_organismo_area_id` varchar(5)
,`desmarca_fecha` date
,`desmarca_hora` time
,`desmarca_SYSusuario` varchar(20)
,`desmarca_organismo_area_id` varchar(5)
,`id_formulario` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `001_documentaciones_tipos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `001_documentaciones_tipos` (
`documentacion_tipo_id` char(5)
,`documentacion_tipo` char(30)
,`documentacion_tipo_orden_aparicion` int(2)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chofer`
--

CREATE TABLE `chofer` (
  `id_chofer` int(11) NOT NULL,
  `apenom` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `domicilio` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `dni` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  `email` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci,
  `telefono` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `organismo_area_id` varchar(5) COLLATE utf8_spanish_ci DEFAULT NULL,
  `licencia_oficial` enum('S','N') COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'S, N',
  `id_tipo` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `clase` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `situacion` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `f_emision` date DEFAULT NULL,
  `f_vencimiento` date DEFAULT NULL,
  `f_inscripcion` datetime DEFAULT NULL,
  `id_parque` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `chofer`
--

INSERT INTO `chofer` (`id_chofer`, `apenom`, `domicilio`, `dni`, `email`, `observa`, `telefono`, `organismo_area_id`, `licencia_oficial`, `id_tipo`, `id_categoria`, `clase`, `situacion`, `f_emision`, `f_vencimiento`, `f_inscripcion`, `id_parque`) VALUES
(1, 'secco sara gabriela', 'Andres Rojas 471', '25946003', '', '', '', '4', 'S', 1, 1, 'clase', 'situacion', '2018-02-14', '2020-03-25', '2019-03-22 12:20:15', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dependencia`
--

CREATE TABLE `dependencia` (
  `id_dependencia` int(11) NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `dependencia`
--

INSERT INTO `dependencia` (`id_dependencia`, `descrip`) VALUES
(1, 'Suelo Urbano'),
(2, 'ARBOLADO URBANO'),
(3, 'C. OPERATIVO Nº 0'),
(4, 'C. OPERATIVO Nº 2'),
(5, 'C. OPERATIVO Nº 3'),
(6, 'C. OPERATIVO Nº 4'),
(7, 'C. OPERATIVO Nº 5'),
(8, 'C. OPERATIVO Nº 9'),
(9, 'CALIDAD DE VIDA'),
(10, 'CEMENTERIO'),
(11, 'CEREMONIAL Y PROTOC.'),
(12, 'CIC CAMPO CONTRERAS'),
(13, 'SECRETARIA DE COORDINACION DE GABINETE'),
(14, 'DEFENSA CIVIL'),
(15, 'DEF. PUEBLO'),
(16, 'DIRECCIÓN DE ELECTRICIDAD'),
(17, 'DIR. HIGIENE'),
(18, 'DIRECCIÓN DE RENTAS'),
(19, 'DIR. TRANSITO'),
(20, 'DIR. TRANSITO MOV. 14'),
(21, 'DIR. TRANSITO MOV. 15'),
(22, 'DIR. TRANSITO MOV. 16'),
(23, 'DIR. TRANSITO MOV. 17'),
(24, 'ECONOMIA'),
(25, 'DIRECCIÓN DE ESTUDIOS Y PROYECTOS'),
(26, 'DIRECCION DE SALUD'),
(27, 'HABILITACIONES'),
(28, 'HIGIENE'),
(29, 'INTENDENCIA'),
(30, 'IR. HIGIENE'),
(31, 'MANTENIMIENTO'),
(32, 'O. PUBLICAS'),
(33, 'O. SALUD'),
(34, 'DIRECCION DE PARQUES Y PASEOS'),
(35, 'PLANEAMIENTO'),
(36, 'S. URBANOS'),
(37, 'SECRETARIA DE ECONOMIA'),
(38, 'SECRETARIA DE GOBIERNO'),
(39, 'SEC. PRIVADA'),
(40, 'SERV. PUBLICOS'),
(41, 'SERV. URBANOS'),
(42, 'SUB. SEC. EDUC.'),
(43, 'SUB. SEC. PLANEAM.'),
(44, 'SUB. SEC. O. PUBLICAS'),
(45, 'U. DESCENTRALIZAC.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `depositario`
--

CREATE TABLE `depositario` (
  `id_depositario` int(11) NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `depositario`
--

INSERT INTO `depositario` (`id_depositario`, `descrip`) VALUES
(1, 'Suelo Urbano'),
(2, 'ARB. URBANO'),
(3, 'C. OPERATIVO Nº 0'),
(4, 'C. OPERATIVO Nº 2'),
(5, 'C. OPERATIVO Nº 3'),
(6, 'C. OPERATIVO Nº 4'),
(7, 'C. OPERATIVO Nº 5'),
(8, 'C. OPERATIVO Nº 9'),
(9, 'CALIDAD DE VIDA'),
(10, 'CEMENTERIO'),
(11, 'CEREMONIAL Y PROTOC.'),
(12, 'CIC CAMPO CONTRERAS'),
(13, 'COORDINACION'),
(14, 'DEFENSA CIVIL'),
(15, 'DEP. PUEBLO'),
(16, 'DIR. ELECTRICIDAD'),
(17, 'DIR. HIGIENE'),
(18, 'DIR. RENTAS'),
(19, 'DIR. TRANSITO'),
(20, 'DIR. TRANSITO MOV. 14'),
(21, 'DIR. TRANSITO MOV. 15'),
(22, 'DIR. TRANSITO MOV. 16'),
(23, 'DIR. TRANSITO MOV. 17'),
(24, 'ECONOMIA'),
(25, 'EST. Y PROYECTO'),
(26, 'FORM 2011 SALUD'),
(27, 'HABILITACIONES'),
(28, 'HIGIENE'),
(29, 'INTENDENCIA'),
(30, 'IR. HIGIENE'),
(31, 'MANTENIMIENTO'),
(32, 'O. PUBLICAS'),
(33, 'O. SALUD'),
(34, 'P. Y PASEOS'),
(35, 'PLANEAMIENTO'),
(36, 'S. URBANOS'),
(37, 'SEC. ECONOMIA'),
(38, 'SEC. GOBIERNO'),
(39, 'SEC. PRIVADA'),
(40, 'SERV. PUBLICOS'),
(41, 'SERV. URBANOS'),
(42, 'SUB. SEC. EDUC.'),
(43, 'SUB. SEC. PLANEAM.'),
(44, 'SUB. SEC. O. PUBLICAS'),
(45, 'U. DESCENTRALIZAC.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entsal`
--

CREATE TABLE `entsal` (
  `id_entsal` int(11) NOT NULL,
  `id_vehiculo` int(11) DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci,
  `f_ent` datetime DEFAULT NULL,
  `id_usuario_ent` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `resp_ent` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `kilo` int(7) DEFAULT NULL,
  `cod_up` int(11) DEFAULT NULL,
  `f_sal` datetime DEFAULT NULL,
  `id_usuario_sal` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `resp_sal` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `asunto` tinyint(1) DEFAULT NULL,
  `diferido` tinyint(1) DEFAULT NULL,
  `estado` enum('E','S','T','A') COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `entsal`
--

INSERT INTO `entsal` (`id_entsal`, `id_vehiculo`, `observa`, `f_ent`, `id_usuario_ent`, `resp_ent`, `kilo`, `cod_up`, `f_sal`, `id_usuario_sal`, `resp_sal`, `total`, `asunto`, `diferido`, `estado`) VALUES
(1, 1, 'tira a la izquierda\nel freno chilla mucho y necesita pisa a fondo', '2019-03-22 11:40:30', 'danielramirez', '', 25000, 0, NULL, NULL, NULL, '7500.00', 1, 0, 'T'),
(2, 137, 'CAMBIO DE ACEITE Y FILTROS', '2019-04-26 09:29:10', 'rsantiagopaz', '', 0, 0, NULL, NULL, NULL, NULL, 1, 0, 'T'),
(3, 52, 'RUIDOS DE CORREA\nHUMEA', '2019-04-26 09:44:19', 'rsantiagopaz', '', 0, 0, NULL, NULL, NULL, NULL, 1, 0, 'T');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `incidente`
--

CREATE TABLE `incidente` (
  `id_incidente` int(11) NOT NULL,
  `id_chofer` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `descrip` text COLLATE utf8_spanish_ci,
  `id_tipo_incidente` int(11) DEFAULT NULL,
  `id_usuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE `movimiento` (
  `id_movimiento` int(11) NOT NULL,
  `id_entsal` int(11) DEFAULT NULL,
  `id_taller` int(11) DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci,
  `f_ent` datetime DEFAULT NULL,
  `id_usuario_ent` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `f_sal` datetime DEFAULT NULL,
  `id_usuario_sal` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `kilo` int(7) DEFAULT NULL,
  `documentacion_id` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `estado` enum('E','S','D','A') COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'E=entrada, S=salida, D=diferido, A=anulado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `movimiento`
--

INSERT INTO `movimiento` (`id_movimiento`, `id_entsal`, `id_taller`, `observa`, `f_ent`, `id_usuario_ent`, `f_sal`, `id_usuario_sal`, `kilo`, `documentacion_id`, `total`, `estado`) VALUES
(1, 1, 2, 'hacer alineado y balanceo\nchequeo de freno', '2019-03-22 11:43:07', 'danielramirez', '2019-03-22 11:51:16', 'danielramirez', 25000, NULL, '7500.00', 'S'),
(2, 1, 1, 'dfdkslñfdslñfnds dsgv', '2019-03-22 12:14:22', 'danielramirez', NULL, NULL, NULL, NULL, NULL, 'E'),
(3, 2, 1, 'CAMBIO DE ACEITE \nFILTROS DE AIRE\nFILTRO DE COMBUSTIBLE\nFILTRO DE HABITACULO', '2019-04-26 09:30:34', 'rsantiagopaz', NULL, NULL, NULL, NULL, NULL, 'E'),
(4, 3, 5, '1- JUEGO DE JUNTAS DE ALTA\nDESCARBONIZACION PARTE\n1- CORREA DE DISTRIBUCION\n1- CORREA DE ALTERNADOR\n1-ARBOL DE LEVAS\n1-MANO DE OBRA', '2019-04-26 09:47:27', 'rsantiagopaz', NULL, NULL, NULL, NULL, NULL, 'E');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parque`
--

CREATE TABLE `parque` (
  `id_parque` int(11) NOT NULL,
  `organismo_area_id` varchar(5) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `parque`
--

INSERT INTO `parque` (`id_parque`, `organismo_area_id`) VALUES
(1, 'DNBPT');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reparacion`
--

CREATE TABLE `reparacion` (
  `id_reparacion` int(11) NOT NULL,
  `id_movimiento` int(11) DEFAULT NULL,
  `id_tipo_reparacion` int(11) DEFAULT NULL,
  `costo` decimal(9,2) DEFAULT NULL,
  `cantidad` smallint(6) DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `reparacion`
--

INSERT INTO `reparacion` (`id_reparacion`, `id_movimiento`, `id_tipo_reparacion`, `costo`, `cantidad`, `total`, `observa`) VALUES
(1, 1, 1, '5000.00', 1, '5000.00', 'se reparo'),
(2, 1, 9, '2500.00', 1, '2500.00', 'alineado de las 4 ruedas y rotacion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsable`
--

CREATE TABLE `responsable` (
  `id_responsable` int(11) NOT NULL,
  `apenom` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `dni` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `domicilio` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  `localidad` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cargo` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `organizacion` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `responsable`
--

INSERT INTO `responsable` (`id_responsable`, `apenom`, `dni`, `domicilio`, `localidad`, `telefono`, `cargo`, `organizacion`) VALUES
(1, 'ramirez daniel', '17890742', '', '', '', '', ''),
(2, 'Cavalieri Omar Anibal', '31729374', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `taller`
--

CREATE TABLE `taller` (
  `id_taller` int(11) NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cuit` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `razon_social` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `categoria_iva` varchar(2) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `taller`
--

INSERT INTO `taller` (`id_taller`, `descrip`, `cuit`, `razon_social`, `categoria_iva`) VALUES
(1, 'Lo Bruno Automotores', '20103405060', 'Lo Bruno SA', '04'),
(2, 'Gemsa', '9080706050', NULL, NULL),
(3, 'HC Mecanica General de Campos Peregrina Maria Soledad', '27-22618110-0', NULL, NULL),
(4, 'Grandes Emprendedores de Rodrigo Gonzalo Coronel', '23-38735664-9', NULL, NULL),
(5, 'Neumaticos y Lubricantes Santiago - Nuevos Emprendimientos SRL', '30-71461661-3', NULL, NULL),
(6, 'Ralenti de Suarez Maria Graciela', '27-14054959-8', NULL, NULL),
(7, 'Maxi-Car taller de Mecanica Integral de Nancy del Carmen juarez', '23-26692906-4', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_incidente`
--

CREATE TABLE `tipo_incidente` (
  `id_tipo_incidente` int(11) NOT NULL,
  `descrip` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_incidente`
--

INSERT INTO `tipo_incidente` (`id_tipo_incidente`, `descrip`) VALUES
(1, 'Choque en vía pùblica'),
(2, 'Paso de semáforo en rojo'),
(3, 'Circular sin documentación'),
(4, 'Circular alcoholizado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_reparacion`
--

CREATE TABLE `tipo_reparacion` (
  `id_tipo_reparacion` int(11) NOT NULL,
  `descrip` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_reparacion`
--

INSERT INTO `tipo_reparacion` (`id_tipo_reparacion`, `descrip`) VALUES
(1, 'Frenos'),
(2, 'Cambio de aceite'),
(3, 'Cambio de Fitlro de Aire'),
(4, 'Cambio de filtro de aceite'),
(5, 'Cambio de filtro de habitáculo'),
(6, 'Embrage'),
(7, 'Reparación motor parte baja'),
(8, 'Reparación motor parte alta'),
(9, 'alineado'),
(10, 'Balanceo'),
(11, 'Chapa'),
(12, 'Pintura'),
(13, 'Tapizado'),
(14, 'Inyectores');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_vehiculo`
--

CREATE TABLE `tipo_vehiculo` (
  `id_tipo_vehiculo` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_vehiculo`
--

INSERT INTO `tipo_vehiculo` (`id_tipo_vehiculo`, `descrip`) VALUES
(1, 'Camioneta'),
(2, 'CORTADORA'),
(3, 'ACOPLADO'),
(4, 'ACOPLADO CARRETON'),
(5, 'AMBULANCIA'),
(6, 'AUTOMOVIL'),
(7, 'BARREDORA'),
(8, 'CAJA METALICA'),
(9, 'CAMION'),
(10, 'CAMION BARREDOR'),
(11, 'CAMION CHASIS C/CAB'),
(12, 'CAMION COMPACTADOR'),
(13, 'CAMION GRUA'),
(14, 'CAMION REGADOR'),
(15, 'CAMION TANQUE'),
(16, 'CAMION VOLCADOR'),
(17, 'CAMIONETA PICK UP'),
(18, 'CARGADORA'),
(19, 'CARGADORA FRONTAL'),
(20, 'COMBI'),
(21, 'CUATRICICLO'),
(22, 'EXCAVADORA'),
(23, 'MOTOCICLETA'),
(24, 'MOTONIVELADORA'),
(25, 'PALA CARGADORA'),
(26, 'PALA MECANICA'),
(27, 'RETROEXCAVADORA'),
(28, 'TANQUE'),
(29, 'TOPADORA'),
(30, 'TOPADORA FRONTAL'),
(31, 'TRACTOR'),
(32, 'TRACTOR DE CARRETERA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculo`
--

CREATE TABLE `vehiculo` (
  `id_vehiculo` int(11) NOT NULL,
  `nro_patente` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_motor` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_tipo_vehiculo` int(11) DEFAULT NULL,
  `modelo` smallint(6) DEFAULT NULL,
  `marca` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_chasis` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `observa` mediumtext COLLATE utf8_spanish_ci,
  `nro_poliza` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `localidad_id` char(5) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_dependencia` int(11) DEFAULT NULL,
  `id_depositario` int(11) DEFAULT NULL,
  `id_responsable` int(11) DEFAULT NULL,
  `id_parque` int(11) DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `estado` enum('E','S','T') COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `vehiculo`
--

INSERT INTO `vehiculo` (`id_vehiculo`, `nro_patente`, `nro_motor`, `id_tipo_vehiculo`, `modelo`, `marca`, `nro_chasis`, `observa`, `nro_poliza`, `localidad_id`, `id_dependencia`, `id_depositario`, `id_responsable`, `id_parque`, `total`, `estado`) VALUES
(1, 'AB850FF', 'HRUF171081074', 1, 2017, 'chevolet', '9BG148CK0JC402795', '', '', '00901', 1, 1, 1, 1, '7500.00', 'T'),
(2, 'DOC-418', 'B32549723', 1, 2000, 'FORD RANGER', 'SAFDR10D11J174650', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(3, 'DOC-421', 'B32549023', 1, 2000, 'FORD RANGER', 'SAFDR10D61J174644', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(4, 'DOC-415', 'B32549589', 1, 2000, 'FORD RANGER', 'SAFDR10D51J174666', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(5, 'BZL-451', 'GS125A198138', 23, 1998, 'SUZUKI', 'GS125A197313', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(6, 'BZL-487', 'GS125A197624', 23, 1998, 'SUZUKI', 'GS125A196970', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(7, 'BZL-449', 'GS125A197601', 23, 1998, 'SUZUKI', 'GS125A196990', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(8, 'CBA-044', 'GS125A197675', 23, 1998, 'SUZUKI', 'GS125A196912', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(9, 'BZL-488', 'GS125A197722', 23, 1998, 'SUZUKI', 'GS125A197001', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(10, 'BZL-486', 'GS125A197542', 23, 1998, 'SUZUKI', 'GS125A196731', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(11, 'BZL-489', 'GS125A197616', 23, 1998, 'SUZUKI', 'GS125A196986', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(12, 'BZL-448', 'GS125A198017', 23, 1998, 'SUZUKI', 'GS125A197299', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(13, 'BZL-450', 'GS125A197606', 23, 1998, 'SUZUKI', 'GS125A196942', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(14, 'BZL-485', 'GS125A198032', 23, 1998, 'SUZUKI', 'GS125A197306', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(15, 'OHM-287', 'F1A074762', 9, 2014, 'VOLKSWAGEN', '9534B8268ER431700', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(16, 'DOC-424', 'B32548535', 1, 2000, 'FORD RANGER', '1J172863', NULL, NULL, '00901', 31, 31, 1, 1, '0.00', 'S'),
(17, 'PAT-079', '3306', 24, 1980, 'ASTARSA', '216', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(18, 'SIN999', 'G021259', 3, 1975, 'MONTENEGRO', '2682', NULL, NULL, '00901', 17, 17, 1, 1, '0.00', 'S'),
(19, 'NOP065', '151/152', 2, 1978, 'HILCORT BMT', '', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(20, 'G0042152', 'SL404845', 13, 1980, 'GROSSPAL', '0601784E', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(21, 'PAT-061', '19940930', 24, 1995, 'CHAMPION', 'X024595', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(22, 'VHU-503', '493398', 8, 1979, 'RASTROJERO', 'F02794', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(23, 'DOC-426', 'DKKBY905023', 1, 2000, 'FORD CURRIER', 'YB905023', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(24, 'OVQ-664', 'CSH112091', 1, 2015, 'VOLKSWAGEN', '8AWDB22H6F027273', NULL, NULL, '00901', 39, 39, 1, 1, '0.00', 'S'),
(25, 'LBG-670', 'J1A025874', 1, 2012, 'FORD RANGER', 'SAFDR12P0CJ469569', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(26, 'NKF-469', '36432593', 9, 2013, 'VOLKSWAGEN', '9533782T9DR338492', NULL, NULL, '00901', 41, 41, 1, 1, '0.00', 'S'),
(27, 'NKF-468', '36430544', 9, 2013, 'VOLKSWAGEN', '9533782TXDR337612', NULL, NULL, '00901', 41, 41, 1, 1, '0.00', 'S'),
(28, 'DOC-419', 'B32550168', 1, 2000, 'FORD RANGER', '8AFDR10D01J174672', NULL, NULL, '00901', 2, 2, 1, 1, '0.00', 'S'),
(29, 'DOC-423', 'B32550121', 1, 2000, 'FORD RANGER', '8AFDR10D51J174649', NULL, NULL, '00901', 1, 1, 1, 1, '0.00', 'S'),
(30, 'DOC-420', 'B32549767', 1, 2000, 'FORD RANGER', '8AFDR10D31J174648', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(31, 'DOC-412', 'DKKBY906210', 1, 2000, 'FORD RANGER', '9BFTSZPPAYB906210', NULL, NULL, '00901', 25, 25, 1, 1, '0.00', 'S'),
(32, '08000PAT', '4CK098192', 23, 1994, 'YAMAHA', 'CH80', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(33, '09500PAT', '156FM198003170', 23, 2000, 'YAMAHA', 'GH125LI980004935', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(34, '09400PAT', '156FM19901858', 23, 2000, 'YAMAHA', 'LAAJCJLB4X0000748', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(35, 'DOC-413', 'DKKBY905851', 1, 2000, 'FORD CURRIER', '9BFTSZPPAYB905851', NULL, NULL, '00901', 38, 38, 1, 1, '0.00', 'S'),
(36, 'LBG-666', '36323016', 9, 2012, 'FORD F-4000 D', '9BFLF4798CB094456', NULL, NULL, '00901', 40, 40, 1, 1, '0.00', 'S'),
(37, 'GOW-398', 'G1T101976', 7, 2007, 'VOLKSWAGEN', '9BWB172S68R802370', NULL, NULL, '00901', 41, 41, 1, 1, '0.00', 'S'),
(38, 'G0012312', 'DLTD49778', 1, 1972, 'FORD', 'JMB00336', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(39, 'CCS00372', '412411', 1, 1998, 'CHEVROLET', 'BGGTFR6DHWA050391', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(40, 'SIN777', '1493', 25, 1980, 'JHON DEERE', '1490', NULL, NULL, '00901', 17, 17, 1, 1, '0.00', 'S'),
(41, 'PAT-072', 'PA4131618', 31, 1974, 'MASSEY FERGUSON', '1866015805', NULL, NULL, '00901', 10, 10, 1, 1, '0.00', 'S'),
(42, 'PAT-067', 'PA3107117', 31, 1974, 'MASSEY FERGUSON', '1685010746', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(43, 'PAT-053', '6229117', 31, 1985, 'MASSEY FERGUSON', '2175038689', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(44, 'A0008189', 'PA6464409', 9, 1970, 'DOGDE', '90A0082E', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(45, 'UTF-045', 'GJAB24112', 1, 1986, 'FORD F-100', 'KB1JGJ-17512', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(46, 'PAT-071', 'PA3112750', 31, 1974, 'MASSEY FERGUSON', '1865035304', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(47, 'DYT-365', '30753419', 16, 2001, 'FORD', '9BFXK84F81B054003', NULL, NULL, '00901', 3, 3, 1, 1, '0.00', 'S'),
(48, 'PAT-056', '3306', 24, 1980, 'ASTARSA', '0215', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(49, 'VHU-515', '91210040177', 16, 1979, 'MERCEDES BENZ', '3415044560', NULL, NULL, '00901', 17, 17, 1, 1, '0.00', 'S'),
(50, 'UTF-046', '341.912-10-0900', 9, 1984, 'MERCEDES BENZ', '341.034-12062443', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(51, 'DOC-417', 'B32549650', 1, 2000, 'FORD RANGER', 'SAFDR10D01J174638', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(52, 'DOC-414', 'DKKBY904936', 1, 2000, 'FORD CURRIER', '9BFTSZPPAYB904936', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'T'),
(53, 'VHU-505', 'PA6491367', 9, 1986, 'FORD', 'GX23903', NULL, NULL, '00901', 4, 4, 1, 1, '0.00', 'S'),
(54, 'VFI-645', '462694', 5, 1987, 'PEUGEOT', '8012637', NULL, NULL, '00901', 33, 33, 1, 1, '0.00', 'S'),
(55, 'VFI-647', '91210061063', 9, 1980, 'MERCEDES BENZ', '3415049997', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(56, 'UTF-050', '34191210080877', 16, 1982, 'MERCEDES BENZ', '34103415058885', NULL, NULL, '00901', 6, 6, 1, 1, '0.00', 'S'),
(57, 'UTF-036', '91210881184', 16, 1982, 'MERCEDES BENZ', '3415059014', NULL, NULL, '00901', 5, 5, 1, 1, '0.00', 'S'),
(58, 'PAT-075', '1269', 25, 1980, 'JHON DEERE', '1254', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(59, 'SIP876', '3114642', 31, 1972, 'MASSEY FERGUSON', '2578043262', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(60, 'NOT987', '3114734', 31, 1972, 'MASSEY FERGUSON', '2578043263', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(61, 'GOW-397', 'G1T101969', 7, 2007, 'VOLKSWAGEN', '9BWB172SX8R802291', NULL, NULL, '00901', 41, 41, 1, 1, '0.00', 'S'),
(62, 'ISL-170', 'C025937', 23, 2012, 'MOTOMEL', '8ELM42250CB025937', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(63, 'ISL-169', 'C025954', 23, 2012, 'MOTOMEL', '8ELM42250CB025954', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(64, 'ISL-171', 'C016942', 23, 2012, 'MOTOMEL', '8ELM42250CB016942', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(65, 'HCG-927', 'M1A309959', 1, 2008, 'CHEVROLET', '9BG138AJ08C426234', NULL, NULL, '00901', 15, 15, 1, 1, '0.00', 'S'),
(66, 'G0028714', 'PA6444357', 9, 1979, 'DOGDE', '886D00080F', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(67, 'NRD-522', '7186270', 9, 2014, 'IVECO', '93ZC53B01E8340848', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(68, 'NRD-523', '7187119', 9, 2014, 'IVECO', '93ZC53B01E8340963', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(69, 'EYT-213', 'JC30E8A500296', 23, 2009, 'HONDA NXR 125', '9C2JD2010AR500296', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(70, 'EYT-209', 'JC30E8A500274', 23, 2009, 'HONDA NXR 125', '9CSJD2010AR500274', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(71, 'EYT-210', 'JC30E8A500256', 23, 2009, 'HONDA NXR 125', '9C2JD2010AR500256', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(72, 'EYT-212', 'JC30E8A500295', 23, 2009, 'HONDA NXR 125', '9C2JD2010AR500295', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(73, 'EYT-211', 'JC30E8A500270', 23, 2009, 'HONDA NXR 125', '9C2JD2010AR500270', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(74, 'VFI-646', '34191210105606', 9, 1986, 'MERCEDES BENZ', '34103412071784', NULL, NULL, '00901', 7, 7, 1, 1, '0.00', 'S'),
(75, 'UTF-041', '341.912-10-1049', 9, 1986, 'MERCEDES BENZ', '341.034-12-071546', NULL, NULL, '00901', 17, 17, 1, 1, '0.00', 'S'),
(76, 'VHU-501', 'KUAE27096', 1, 1990, 'FORD', 'KB1JKU27985', NULL, NULL, '00901', 29, 29, 1, 1, '0.00', 'S'),
(77, 'UTF-048', 'GJAB23999', 1, 1986, 'FORD', 'KB1JGJ-17513', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(78, 'UTF-053', '341912-10-09039', 9, 1984, 'MERCEDES BENZ', '341034-12-062698', NULL, NULL, '00901', 17, 17, 1, 1, '0.00', 'S'),
(79, 'VHU-504', 'PA64911384', 15, 1986, 'FORD', 'GLGS25099', NULL, NULL, '00901', 17, 17, 1, 1, '0.00', 'S'),
(80, 'G0038061', '6491118', 12, 1986, 'FORD', 'KBGLGJ18011', NULL, NULL, '00901', 17, 17, 1, 1, '0.00', 'S'),
(81, 'VLG-652', 'IK600420', 6, 1986, 'CITROEN', 'CH13', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(82, 'UTF-052', '341.912-10-0610', 9, 1980, 'MERCEDES BENZ', '341-034-15-049996', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(83, 'UTF-035', '341.912-10-0599', 9, 1980, 'MERCEDES BENZ', '341.034-15-049998', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(84, 'UTF-037', '341.912-10-0611', 9, 1980, 'MERCEDES BENZ', '341.034-15-050023', NULL, NULL, '00901', 17, 17, 1, 1, '0.00', 'S'),
(85, 'UTF-049', 'PA6491393', 15, 1986, 'FORD', 'KB6LGS-25102', NULL, NULL, '00901', 17, 17, 1, 1, '0.00', 'S'),
(86, 'PAT-059', '3304', 29, 1980, 'CATERPILLAR', '46V5031', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(87, 'VFI-648', 'PA6491322', 16, 1985, 'FORD', 'KB6LGS24221', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(88, 'P0000070', 'PA3150136', 25, 1979, 'CRIBSA', '1', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(89, 'DOC-416', 'B32550366', 1, 2000, 'FORD RANGER', 'SAFDR10D71J175091', NULL, NULL, '00901', 45, 45, 1, 1, '0.00', 'S'),
(90, 'PAT-056', '3306', 24, 1980, 'ASTARSA', '3305214', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(91, 'PAT-058', '3306', 26, 1980, 'ASTARSA', '7N4388GG', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(92, 'PAT-060', '1075', 22, 1980, 'POCLAIN', '405079', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(93, 'SIN-053', '6229117', 31, 1985, 'MASSEY FERGUSON', '2175038689', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(94, 'SIN-069', '6239985', 31, 1979, 'MASSEY FERGUSON', '2174045654', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(95, 'PAT-077', '62399960', 31, 1980, 'MASSEY FERGUSON', '2174045657', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(96, 'NOT-123', '1545', 24, 1979, 'JHON DEERE', '2517', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(97, 'NOT-124', '1223', 24, 1974, 'JHON DEERE', '2218', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(98, 'NOT-125', '1271', 24, 1974, 'JHON DEERE', '2270', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(99, 'PAT-069', 'PA6236499', 30, 1979, 'MASSEY FERGUSON', '2174043643', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(100, 'PAT-055', 'PA4169936', 31, 1980, 'MASSEY FERGUSON', '2173046153', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(101, 'PAT-068', 'PA4173605', 31, 1980, 'MASSEY FERGUSON', '2173046154', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(102, 'G0034569', 'YS450', 1, 1978, 'CHEVROLET', 'F170756', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(103, 'PAT-057', 'PA6443840', 26, 1976, 'MICHIGAN', 'H4021A520', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(104, 'EKO-369', 'C20156361', 1, 2004, 'FORD RANGER', 'SAFDR12F34J358250', NULL, NULL, '00901', 38, 38, 1, 1, '0.00', 'S'),
(105, 'DOC-422', 'B32549801', 1, 2000, 'FORD RANGER', 'SAFDR10D61J175051', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(106, 'UTF-053', '341.912-10-0611', 9, 1980, 'MERCEDES BENZ', '341.034-15-050019', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(107, 'DOC-411', 'DKKBY904926', 1, 2000, 'FORD COURIER', 'YB94926', NULL, NULL, '00901', 35, 35, 1, 1, '0.00', 'S'),
(108, 'FLK-749', '30210140', 9, 2006, 'FORD F-4000 D', '9BFLF476X5B026239', NULL, NULL, '00901', 37, 37, 1, 1, '0.00', 'S'),
(109, 'ALM-040', 'RPA336791', 24, 1999, 'CHAMPION', 'X029542X', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(110, 'ALM-043', 'RD210825375', 31, 1999, 'STONE DEUTZ', '799169', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(111, 'CTE-948', '3126034', 9, 1999, 'SCANIA', 'W3506297', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(112, 'ALM-050', '376910-007-4345', 19, 1999, 'MICHIGAN', '4247S-1877-BRC', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(113, 'PAT-066', '1650093', 25, 1977, 'CRIBSA', '5303', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(114, 'JER-444', '36153881', 9, 2010, 'FORD', '9BFLF4790AB072691', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(115, 'ELA-190', 'C20156293', 1, 2004, 'FORD RANGER', 'SAFDR12F34J358278', NULL, NULL, '00901', 24, 24, 1, 1, '0.00', 'S'),
(116, 'DOT-533', '30750248', 9, 2000, 'FORD F-14000', '9BFXK84F31D047772', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(117, 'DOT-531', '30750119', 9, 2000, 'FORD F-14000', '9BFXK84F11D047415', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(118, 'DOT-530', '30749955', 9, 2000, 'FORD F-14000', '9BFXk84F41D039616', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(119, 'VHU-506', '91210040296', 16, 1979, 'MERCEDES BENZ', '3415044609', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(120, 'VHU-507', '91210040083', 16, 1979, 'MERCEDES BENZ', '3415044241', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(121, 'DOC-425', 'B32548840', 1, 2000, 'FORD RANGER', 'SAFDR10D91J172337', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(122, 'CTE-949', '3125580', 9, 1999, 'SCANIA', 'W3506296', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(123, 'DOT-532', '30750306', 9, 2000, 'FORD F-14000', '9BFXK84F11D047771', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(124, 'ALM-041', 'RPA336790', 24, 1999, 'CHAMPION', 'X0X29541X', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(125, 'ALE-731', '230A20001633072', 1, 1995, 'FIAT DUCATO', 'ZFA23000005120975', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(126, 'LCM-039', 'G1T100121', 7, 2007, 'BICUPIRO', '9BWB172SX7R719443', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(127, 'EUC-735', 'C20171847', 1, 2005, 'FORD RANGER', 'SAFDR12F55J403593', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(128, 'KPW-944', '36335405', 9, 2011, 'FORD F-4000 D', '9BFLF4793CB097197', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(129, 'CSH-514', 'JC30E86501125', 23, 2006, 'HONDA NXR 125', '9C2JD20106R501125', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(130, 'CSH-515', 'JC30E86501117', 23, 2006, 'HONDA NXR 125', '9C2JD20106R501117', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(131, 'CSH-516', 'JC30E86501162', 23, 2006, 'HONDA NXR 125', '9C2JD20106R501162', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(132, 'CSH-517', 'JC30E86500957', 23, 2006, 'HONDA NXR 125', '9C5JD20106R500957', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(133, 'CSH-518', 'JC30E86500958', 23, 2006, 'HONDA NXR 125', '9C5JD20106R500958', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(134, 'OMJ-009', '7206848', 9, 2014, 'IVECO', '93ZC53B01E8343026', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(135, 'CVK-049', '6B13J017936', 19, 2013, 'DEUTZ', 'LFJ00833KDAA80365', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(136, 'PBT-824', 'P1A033530', 9, 2015, 'VOLKSWAGEN', '9531952P1GR521618', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(137, 'PBT-825', 'P1A033516', 9, 2015, 'VOLKSWAGEN', '9531952P6FR519085', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'T'),
(138, 'PCD-631', 'QW2PFJ322080', 1, 2015, 'FORD RANGER', '8AFAR22J0FJ322080', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(139, 'PCD-630', 'QW2PFJ322081', 1, 2015, 'FORD RANGER', '8AFAR22J2FJ322081', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(140, 'CMH-950', 'JC30E85504136', 23, 2005, 'HONDA NXR 125', '9C2JD20105R504136', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(141, 'CMH-951', 'JC30E85504196', 23, 2005, 'HONDA NXR 125', '9C2JD20105R504146', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(142, 'CMH-952', 'JC30E85504210', 23, 2005, 'HONDA NXR 125', '9C2JD20105R504210', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(143, 'CMH-953', 'JC30E85503525', 23, 2005, 'HONDA NXR 125', '9C2JD20105R503525', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(144, 'CMH-954', 'JC30E85504196', 23, 2005, 'HONDA NXR 125', '9C2JD20105R504196', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(145, 'EKO-368', 'C201056306', 1, 2004, 'FORD RANGER', 'SAFDR12F34J3585', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(146, 'G0034407', '34191210081209', 9, 1974, 'MERCEDES BENZ', '34103415059013', NULL, NULL, '00901', 17, 17, 1, 1, '0.00', 'S'),
(147, 'ETY-689', '40704198628', 1, 2005, 'CHEVROLET', '9BG138AC05C414173', NULL, NULL, '00901', 1, 1, 1, 1, '0.00', 'S'),
(148, 'EZD-061', '37798310612517', 9, 2005, 'MERCEDES BENZ', '9BM6950145B398991', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(149, 'CVK-00', '12085516', 9, 2014, 'MICHIGAN', '2M1495', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(150, 'LBG-669', 'L1A024321', 1, 2012, 'FORD RANGER', 'SAFDR12P3CJ469579', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(151, 'AXR-066', '30379447', 31, 2006, 'CUMMIS', 'CC5955', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(152, 'HER-550', 'M1A312640', 1, 2008, 'NISSAN', '94DCEGD228J002344', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(153, 'IQD-258', '36153881', 9, 2010, 'FORD F-4000 D', '9BFLF4790AB072691', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(154, 'AXR-067', '30380008', 24, 2006, 'ZANELLO', 'MA0012', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(155, 'ABM-104', 'UN987002', 6, 1994, 'VOLKSWAGEN', 'SAWZZZ30ZRJ048524', NULL, NULL, '00901', 18, 18, 1, 1, '0.00', 'S'),
(156, 'GSV-929', 'C34237494', 1, 2008, 'FORD RANGER', 'SAFDR12P98J117260', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(157, 'AXR-080', 'SC8B08B670595L', 31, 2004, 'MASSEY FERGUSON', '2752178170', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(158, 'BDQ-002', '30379507', 24, 2006, 'CUMMIS', 'MA0010', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(159, 'BDQ-003', '30799392', 24, 2006, 'CUMMIS', 'MA0011', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(160, 'HJQ-557', '1028809', 1, 2008, 'CITROEN', '935ZBPMFB82024366', NULL, NULL, '00901', 26, 26, 1, 1, '0.00', 'S'),
(161, 'OYL-957', 'QW2PFJ324329', 1, 2015, 'FORD RANGER', '8AFAR22J0FJ324329', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(162, 'OYL-958', 'QW2PFJ323465', 1, 2015, 'FORD RANGER', '8AFAR22J3FJ323465', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(163, 'OYL-955', 'QW2PFJ339353', 1, 2015, 'FORD RANGER', '8AFAR22J6FJ339353', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(164, 'OYL-956', 'QW2PFJ327658', 1, 2015, 'FORD RANGER', '8AFAR22J1FJ327658', NULL, NULL, '00901', 19, 19, 1, 1, '0.00', 'S'),
(165, 'LBG-668', '36321725', 9, 2012, 'FORD F-4000 D', '9BFLF4794CB094454', NULL, NULL, '00901', 40, 40, 1, 1, '0.00', 'S'),
(166, 'KZY-043', 'K9KA700D182500', 6, 2012, 'RENAULT KANGOO', '8A1FCG715CL809601', NULL, NULL, '00901', 12, 12, 1, 1, '0.00', 'S'),
(167, 'BYN-065', 'I41AC74763097E', 31, 2010, 'MASSEY FERGUSON', 'BUA44002', NULL, NULL, '00901', 34, 34, 1, 1, '0.00', 'S'),
(168, 'PFU-835', 'QW2PGJ373522', 1, 2015, 'FORD RANGER', '8AFAR22J6GJ373522', NULL, NULL, '00901', 38, 38, 1, 1, '0.00', 'S'),
(169, 'PFU-834', 'QW2PGJ367457', 1, 2015, 'FORD RANGER', '8AFAR22J2GJ367457', NULL, NULL, '00901', 42, 42, 1, 1, '0.00', 'S'),
(170, 'PFF-476', 'BG2G142201110', 1, 2015, 'CHEVROLET', '9BG148CK0GC402962', NULL, NULL, '00901', 24, 24, 1, 1, '0.00', 'S'),
(171, 'PNF-110', 'F4AE0681D801479', 32, 2015, 'IVECO', '8ATM1NFH0FX095322', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(172, 'PNF-111', 'F4AE0681D801475', 32, 2015, 'IVECO', '8ATM1NFH0FX095321', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(173, 'CVK-091', 'H729303', 24, 2016, 'DEUTZ', '145131', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(174, 'PFF-475', 'BG2G142181217', 1, 2015, 'CHEVROLET', '9BG148CK0GC403380', NULL, NULL, '00901', 43, 43, 1, 1, '0.00', 'S'),
(175, 'CVK-095', '36530347', 24, 2016, 'PAUNY', 'MA0380', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(176, 'DCI-039', 'RG75486R020329A', 27, 2015, 'HYUNDAI', 'HHKHU601EF0000596', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(177, 'DCI-046', 'RG75486R020316A', 27, 2015, 'HYUNDAI', 'HHKHU601TF0000598', NULL, NULL, '00901', 32, 32, 1, 1, '0.00', 'S'),
(178, '864-SIP', '8057870', 21, 2010, 'PITBULL', '8ELM432008B057870', NULL, NULL, '00901', 14, 14, 1, 1, '0.00', 'S'),
(179, '773-SIP', 'LC152FMHVC00992', 21, 2010, 'MONDIAL', 'LLCLSH3068F000801', NULL, NULL, '00901', 14, 14, 1, 1, '0.00', 'S'),
(180, 'HYE-261', 'K4MJ7309044982', 6, 2010, 'RENAULT KANGOO', '8A1KCI0259L218711', NULL, NULL, '00901', 11, 11, 1, 1, '0.00', 'S'),
(181, 'HMG-061', '10DBG0022535', 6, 2008, 'PEUDEOT 206', '8A02ANGAD9G01695', NULL, NULL, '00901', 27, 27, 1, 1, '0.00', 'S'),
(182, 'DFM-056', 'S325EG-59123', 31, 2016, 'MASSEY FERGUSON', '8AAT0001JGG000049', NULL, NULL, '00901', 9, 9, 1, 1, '0.00', 'S'),
(183, 'AB850FQ', 'HRUF171071069', 17, 2017, 'CHEVROLET', '9BG148CK0JC402776', NULL, NULL, '00901', 44, 44, 1, 1, '0.00', 'S'),
(184, 'AB850FG', 'HRUF171081101', 17, 2017, 'CHEVROLET', '9BG148CK0JC402787', NULL, NULL, '00901', 40, 40, 1, 1, '0.00', 'S'),
(185, 'AB850FH', 'HRUF171091025', 17, 2017, 'CHEVROLET', '9BG148CK0JC402786', NULL, NULL, '00901', 13, 13, 1, 1, '0.00', 'S'),
(186, 'AB850FI', 'HRUF171141163', 17, 2017, 'CHEVROLET', '9BG144CK0JC405232', NULL, NULL, '00901', 3, 3, 1, 1, '0.00', 'S'),
(187, 'AB850FM', 'HRUF171251125', 17, 2017, 'CHEVROLET', '9BG144CK0JC406088', NULL, NULL, '00901', 8, 8, 1, 1, '0.00', 'S'),
(188, 'AB850FK', 'HRUF171291034', 17, 2017, 'CHEVROLET', '9BG144CK0JC406100', NULL, NULL, '00901', 4, 4, 1, 1, '0.00', 'S'),
(189, 'AC249XD', '7262919', 11, 2017, 'IVECO', '93ZC53C01J8476405', NULL, NULL, '00901', 16, 16, 1, 1, '0.00', 'S'),
(190, 'AD260PD', 'MGDAKJ114923', 6, 2018, 'FORD', '8AFBZZFFCKJ114923', NULL, NULL, '00901', 29, 29, 1, 1, '0.00', 'S');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `_auditoria`
--

CREATE TABLE `_auditoria` (
  `id_auditoria` int(11) NOT NULL,
  `fecha` datetime DEFAULT NULL,
  `sql_texto` text COLLATE utf8_spanish_ci,
  `id` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tag` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `_auditoria`
--

INSERT INTO `_auditoria` (`id_auditoria`, `fecha`, `sql_texto`, `id`, `tag`, `usuario`) VALUES
(1, '2019-03-22 11:36:22', 'INSERT vehiculo SET id_vehiculo=\'0\', nro_patente=\'AB850FF\', marca=\'chevolet\', id_tipo_vehiculo=\'2\', modelo=\'2017\', nro_motor=\'HRUF171081074\', nro_chasis=\'9BG148CK0JC402795\', observa=\'\', nro_poliza=\'\', localidad_id=\'00901\', id_dependencia=\'2\', id_depositario=\'7\', id_responsable=\'1\', id_parque=1, total=0, estado=\'S\'', '1', 'insert_vehiculo', 'danielramirez'),
(2, '2019-03-22 11:40:30', 'UPDATE vehiculo SET estado=\'E\' WHERE id_vehiculo=1', '1', 'update_vehiculo', 'danielramirez'),
(3, '2019-03-22 11:40:30', 'INSERT entsal SET id_vehiculo=1, observa=\'tira a la izquierda\nel freno chilla mucho y necesita pisa a fondo\', f_ent=NOW(), id_usuario_ent=\'danielramirez\', resp_ent=\'\', kilo=25000, cod_up=0, asunto=FALSE, diferido=FALSE, estado=\'E\'', '1', 'insert_entsal', 'danielramirez'),
(4, '2019-03-22 11:43:07', 'INSERT movimiento SET id_entsal=1, id_taller=2, observa=\'hacer alineado y balanceo\nchequeo de freno\', f_ent=NOW(), id_usuario_ent=\'danielramirez\', estado=\'E\'', '1', 'insert_movimiento', 'danielramirez'),
(5, '2019-03-22 11:51:16', 'UPDATE movimiento SET f_sal=NOW(), id_usuario_sal=\'danielramirez\', kilo=25000, estado=\'S\' WHERE id_movimiento=1', '1', 'update_movimiento', 'danielramirez'),
(6, '2019-03-22 11:51:16', 'INSERT reparacion SET costo=\'5000\', cantidad=\'1\', total=\'5000\', observa=\'se reparo\', id_movimiento=\'1\', id_tipo_reparacion=\'1\'', '1', 'insert_reparacion', 'danielramirez'),
(7, '2019-03-22 11:51:16', 'INSERT reparacion SET costo=\'2500\', cantidad=\'1\', total=\'2500\', observa=\'alineado de las 4 ruedas y rotacion\', id_movimiento=\'1\', id_tipo_reparacion=\'9\'', '2', 'insert_reparacion', 'danielramirez'),
(8, '2019-03-22 12:14:22', 'INSERT movimiento SET id_entsal=1, id_taller=1, observa=\'dfdkslñfdslñfnds dsgv\', f_ent=NOW(), id_usuario_ent=\'danielramirez\', estado=\'E\'', '2', 'insert_movimiento', 'danielramirez'),
(11, '2019-03-22 12:20:15', 'INSERT chofer SET id_chofer=\'0\', dni=\'25946003\', apenom=\'secco sara gabriela\', email=\'\', observa=\'\', telefono=\'\', organismo_area_id=\'4\', licencia_oficial=\'S\', id_tipo=\'1\', id_categoria=\'1\', f_emision=\'2018-02-14 00:00:00\', f_vencimiento=\'2020-03-25 00:00:00\', id_parque=1, f_inscripcion=NOW()', '1', 'insert_chofer', 'danielramirez'),
(13, '2019-04-16 10:39:38', 'INSERT taller SET id_taller=\'0\', descrip=\'HC Mecanica General de Campos Peregrina Maria Soledad\', cuit=\'27-22618110-0\'', '3', 'insert_taller', 'ocavalieri'),
(14, '2019-04-16 11:53:03', 'INSERT responsable SET id_responsable=\'0\', apenom=\'Cavalieri Omar Anibal\', dni=\'31729374\', domicilio=\'\', localidad=\'\', telefono=\'\', cargo=\'\', organizacion=\'\'', '2', 'insert_responsable', 'ocavalieri'),
(15, '2019-04-16 12:06:00', 'INSERT vehiculo SET id_vehiculo=\'0\', nro_patente=\'OVQ664\', marca=\'VOLSKWAGEN\', id_tipo_vehiculo=\'2\', modelo=\'2015\', nro_motor=\'CSH112091\', nro_chasis=\'8AWDB22H6FA027273\', observa=\'\', nro_poliza=\'\', localidad_id=\'00901\', id_dependencia=\'5\', id_depositario=\'4\', id_responsable=\'2\', id_parque=1, total=0, estado=\'S\'', '2', 'insert_vehiculo', 'ocavalieri'),
(16, '2019-04-16 12:27:16', 'INSERT taller SET id_taller=\'0\', descrip=\'Grandes Emprendedores de Rodrigo Gonzalo Coronel\', cuit=\'23-38735664-9\'', '4', 'insert_taller', 'ocavalieri'),
(17, '2019-04-16 12:29:07', 'INSERT taller SET id_taller=\'0\', descrip=\'Neumaticos y Lubricantes Santiago - Nuevos Emprendimientos SRL\', cuit=\'30-71461661-3\'', '5', 'insert_taller', 'ocavalieri'),
(18, '2019-04-16 12:30:11', 'INSERT taller SET id_taller=\'0\', descrip=\'Ralenti de Suarez Maria Graciela\', cuit=\'27-14054959-8\'', '6', 'insert_taller', 'ocavalieri'),
(19, '2019-04-16 12:31:19', 'INSERT taller SET id_taller=\'0\', descrip=\'Maxi-Car taller de Mecanica Integral de Nancy del Carmen juarez\', cuit=\'23-26692906-4\'', '7', 'insert_taller', 'ocavalieri'),
(20, '2019-04-26 08:49:36', 'UPDATE vehiculo SET id_vehiculo=\'146\', nro_patente=\'G0034407\', nro_motor=\'34191210081209\', id_tipo_vehiculo=\'9\', modelo=\'1974\', marca=\'MERCEDES BENZ\', nro_chasis=\'34103415059013\', observa=NULL, nro_poliza=NULL, localidad_id=\'00901\', id_dependencia=\'17\', id_depositario=\'17\', id_responsable=\'1\', id_parque=\'1\' WHERE id_vehiculo=146', '146', 'update_vehiculo', 'rsantiagopaz'),
(21, '2019-04-26 08:50:31', 'UPDATE vehiculo SET id_vehiculo=\'18\', nro_patente=\'SIN999\', nro_motor=\'G021259\', id_tipo_vehiculo=\'3\', modelo=\'1975\', marca=\'MONTENEGRO\', nro_chasis=\'2682\', observa=NULL, nro_poliza=NULL, localidad_id=\'00901\', id_dependencia=\'17\', id_depositario=\'17\', id_responsable=\'1\', id_parque=\'1\' WHERE id_vehiculo=18', '18', 'update_vehiculo', 'rsantiagopaz'),
(22, '2019-04-26 08:51:10', 'UPDATE vehiculo SET id_vehiculo=\'49\', nro_patente=\'VHU-515\', nro_motor=\'91210040177\', id_tipo_vehiculo=\'16\', modelo=\'1979\', marca=\'MERCEDES BENZ\', nro_chasis=\'3415044560\', observa=NULL, nro_poliza=NULL, localidad_id=\'00901\', id_dependencia=\'17\', id_depositario=\'17\', id_responsable=\'1\', id_parque=\'1\' WHERE id_vehiculo=49', '49', 'update_vehiculo', 'rsantiagopaz'),
(23, '2019-04-26 08:56:19', 'UPDATE vehiculo SET id_vehiculo=\'161\', nro_patente=\'OYL-957\', nro_motor=\'QW2PFJ324329\', id_tipo_vehiculo=\'1\', modelo=\'2015\', marca=\'FORD RANGER\', nro_chasis=\'8AFAR22J0FJ324329\', observa=NULL, nro_poliza=NULL, localidad_id=\'00901\', id_dependencia=\'19\', id_depositario=\'19\', id_responsable=\'1\', id_parque=\'1\' WHERE id_vehiculo=161', '161', 'update_vehiculo', 'rsantiagopaz'),
(24, '2019-04-26 08:56:56', 'UPDATE vehiculo SET id_vehiculo=\'164\', nro_patente=\'OYL-956\', nro_motor=\'QW2PFJ327658\', id_tipo_vehiculo=\'1\', modelo=\'2015\', marca=\'FORD RANGER\', nro_chasis=\'8AFAR22J1FJ327658\', observa=NULL, nro_poliza=NULL, localidad_id=\'00901\', id_dependencia=\'19\', id_depositario=\'19\', id_responsable=\'1\', id_parque=\'1\' WHERE id_vehiculo=164', '164', 'update_vehiculo', 'rsantiagopaz'),
(25, '2019-04-26 08:57:27', 'UPDATE vehiculo SET id_vehiculo=\'163\', nro_patente=\'OYL-955\', nro_motor=\'QW2PFJ339353\', id_tipo_vehiculo=\'1\', modelo=\'2015\', marca=\'FORD RANGER\', nro_chasis=\'8AFAR22J6FJ339353\', observa=NULL, nro_poliza=NULL, localidad_id=\'00901\', id_dependencia=\'19\', id_depositario=\'19\', id_responsable=\'1\', id_parque=\'1\' WHERE id_vehiculo=163', '163', 'update_vehiculo', 'rsantiagopaz'),
(26, '2019-04-26 08:57:58', 'UPDATE vehiculo SET id_vehiculo=\'162\', nro_patente=\'OYL-958\', nro_motor=\'QW2PFJ323465\', id_tipo_vehiculo=\'1\', modelo=\'2015\', marca=\'FORD RANGER\', nro_chasis=\'8AFAR22J3FJ323465\', observa=NULL, nro_poliza=NULL, localidad_id=\'00901\', id_dependencia=\'19\', id_depositario=\'19\', id_responsable=\'1\', id_parque=\'1\' WHERE id_vehiculo=162', '162', 'update_vehiculo', 'rsantiagopaz'),
(27, '2019-04-26 09:29:10', 'UPDATE vehiculo SET estado=\'E\' WHERE id_vehiculo=137', '137', 'update_vehiculo', 'rsantiagopaz'),
(28, '2019-04-26 09:29:10', 'INSERT entsal SET id_vehiculo=137, observa=\'CAMBIO DE ACEITE Y FILTROS\', f_ent=NOW(), id_usuario_ent=\'rsantiagopaz\', resp_ent=\'\', kilo=0, cod_up=0, asunto=FALSE, diferido=FALSE, estado=\'E\'', '2', 'insert_entsal', 'rsantiagopaz'),
(29, '2019-04-26 09:30:34', 'INSERT movimiento SET id_entsal=2, id_taller=1, observa=\'CAMBIO DE ACEITE \nFILTROS DE AIRE\nFILTRO DE COMBUSTIBLE\nFILTRO DE HABITACULO\', f_ent=NOW(), id_usuario_ent=\'rsantiagopaz\', estado=\'E\'', '3', 'insert_movimiento', 'rsantiagopaz'),
(30, '2019-04-26 09:44:19', 'UPDATE vehiculo SET estado=\'E\' WHERE id_vehiculo=52', '52', 'update_vehiculo', 'rsantiagopaz'),
(31, '2019-04-26 09:44:19', 'INSERT entsal SET id_vehiculo=52, observa=\'RUIDOS DE CORREA\nHUMEA\', f_ent=NOW(), id_usuario_ent=\'rsantiagopaz\', resp_ent=\'\', kilo=0, cod_up=0, asunto=FALSE, diferido=FALSE, estado=\'E\'', '3', 'insert_entsal', 'rsantiagopaz'),
(32, '2019-04-26 09:47:27', 'INSERT movimiento SET id_entsal=3, id_taller=5, observa=\'1- JUEGO DE JUNTAS DE ALTA\nDESCARBONIZACION PARTE\n1- CORREA DE DISTRIBUCION\n1- CORREA DE ALTERNADOR\n1-ARBOL DE LEVAS\n1-MANO DE OBRA\', f_ent=NOW(), id_usuario_ent=\'rsantiagopaz\', estado=\'E\'', '4', 'insert_movimiento', 'rsantiagopaz'),
(33, '2019-05-10 07:34:23', 'UPDATE taller SET id_taller=\'1\', descrip=\'Lo Bruno Automotores\', cuit=\'20103405060\', razon_social=\'Lo Bruno SA\', categoria_iva=\'07\' WHERE id_taller=1', '1', 'update_taller', 'rsantiagopaz'),
(34, '2019-05-10 07:45:38', 'UPDATE chofer SET id_chofer=\'1\', apenom=\'secco sara gabriela\', domicilio=\'Andres Rojas 471\', dni=\'25946003\', email=\'\', observa=\'\', telefono=\'\', organismo_area_id=\'4\', licencia_oficial=\'S\', id_tipo=\'1\', id_categoria=\'1\', clase=\'clase\', situacion=\'situacion\', f_emision=\'2018-02-14 00:00:00\', f_vencimiento=\'2020-03-25 00:00:00\', f_inscripcion=\'2019-03-22 12:20:15\', id_parque=\'1\' WHERE id_chofer=1', '1', 'update_chofer', 'rsantiagopaz'),
(35, '2019-05-10 09:39:15', 'UPDATE taller SET id_taller=\'1\', descrip=\'Lo Bruno Automotores\', cuit=\'20103405060\', razon_social=\'Lo Bruno SA\', categoria_iva=\'04\' WHERE id_taller=1', '1', 'update_taller', 'rsantiagopaz');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_departamentos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_departamentos` (
`departamento_id` char(2)
,`departamento` char(10)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_localidades`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_localidades` (
`localidad_id` char(5)
,`departamento_id` char(2)
,`localidad` char(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_organismos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_organismos` (
`organismo_id` char(10)
,`organismo` char(100)
,`organismo_tipo` char(1)
,`domicilio` char(50)
,`telefonos` char(50)
,`localidad_id` char(5)
,`organismo_expediente_codigo` int(3)
,`organismo_expediente_ultimonumero` int(5)
,`organismo_expediente_ultimoano` int(4)
,`estado` char(1)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_organismos_areas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_organismos_areas` (
`organismo_area_id` varchar(5)
,`organismo_area_tipo_id` char(2)
,`organismo_area` varchar(100)
,`organismo_area_descripcion` text
,`organismo_id` varchar(10)
,`organismo_area_estado` char(1)
,`organismo_area_mesa_entrada` char(1)
,`organismo_area_archivo` char(1)
,`max_dias_pendiente_recepcion` int(2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_organismos_areas_usuarios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_organismos_areas_usuarios` (
`organismo_area_id` char(5)
,`SYSusuario` char(20)
,`cargo` char(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_sistemas_usuarios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_sistemas_usuarios` (
`sistema_id` char(3)
,`SYSusuario` char(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_usuarios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_usuarios` (
`SYSusuario` varchar(20)
,`SYSpassword` varchar(32)
,`SYSusuarionombre` varchar(50)
,`SYSusuario_sexo` char(1)
,`SYSusuario_dni` int(8)
,`SYSusuario_cuil` int(11)
,`SYSusuarioemail` varchar(100)
,`SYSusuario_comentario` text
,`SYSusuario_estado` int(1)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `001_documentaciones`
--
DROP TABLE IF EXISTS `001_documentaciones`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `001_documentaciones`  AS  select `tierras`.`001_documentaciones`.`documentacion_id` AS `documentacion_id`,`tierras`.`001_documentaciones`.`documentacion_tmp_iniciador` AS `documentacion_tmp_iniciador`,`tierras`.`001_documentaciones`.`documentacion_tmp_asunto` AS `documentacion_tmp_asunto`,`tierras`.`001_documentaciones`.`documentacion_tmp_SYSusuario` AS `documentacion_tmp_SYSusuario`,`tierras`.`001_documentaciones`.`documentacion_tmp_estado` AS `documentacion_tmp_estado`,`tierras`.`001_documentaciones`.`documentacion_tipo_id` AS `documentacion_tipo_id`,`tierras`.`001_documentaciones`.`documentacion_tipo_otro` AS `documentacion_tipo_otro`,`tierras`.`001_documentaciones`.`documentacion_numero` AS `documentacion_numero`,`tierras`.`001_documentaciones`.`documentacion_numero_ano` AS `documentacion_numero_ano`,`tierras`.`001_documentaciones`.`documentacion_numero_documentacion_tipo_id` AS `documentacion_numero_documentacion_tipo_id`,`tierras`.`001_documentaciones`.`documentacion_organismo_area_id` AS `documentacion_organismo_area_id`,`tierras`.`001_documentaciones`.`iniciador_tipo` AS `iniciador_tipo`,`tierras`.`001_documentaciones`.`iniciador_persona_id` AS `iniciador_persona_id`,`tierras`.`001_documentaciones`.`iniciador_organismo_id` AS `iniciador_organismo_id`,`tierras`.`001_documentaciones`.`iniciador_organismo_area_id` AS `iniciador_organismo_area_id`,`tierras`.`001_documentaciones`.`iniciador_otro` AS `iniciador_otro`,`tierras`.`001_documentaciones`.`expediente_numero` AS `expediente_numero`,`tierras`.`001_documentaciones`.`expediente_codigo` AS `expediente_codigo`,`tierras`.`001_documentaciones`.`expediente_ano` AS `expediente_ano`,`tierras`.`001_documentaciones`.`expediente_fecha` AS `expediente_fecha`,`tierras`.`001_documentaciones`.`expediente_SYSusuario` AS `expediente_SYSusuario`,`tierras`.`001_documentaciones`.`expediente_estado` AS `expediente_estado`,`tierras`.`001_documentaciones`.`expediente_estado_suspendido_hasta` AS `expediente_estado_suspendido_hasta`,`tierras`.`001_documentaciones`.`expediente_estado_suspendido_hasta_SYSusuario` AS `expediente_estado_suspendido_hasta_SYSusuario`,`tierras`.`001_documentaciones`.`documentacion_asunto` AS `documentacion_asunto`,`tierras`.`001_documentaciones`.`documentacion_asunto_tipo_id` AS `documentacion_asunto_tipo_id`,`tierras`.`001_documentaciones`.`documentacion_asunto_tipo_otro` AS `documentacion_asunto_tipo_otro`,`tierras`.`001_documentaciones`.`documentacion_fecha_inicio` AS `documentacion_fecha_inicio`,`tierras`.`001_documentaciones`.`documentacion_fecha` AS `documentacion_fecha`,`tierras`.`001_documentaciones`.`documentacion_hora` AS `documentacion_hora`,`tierras`.`001_documentaciones`.`documentacion_folios` AS `documentacion_folios`,`tierras`.`001_documentaciones`.`documentacion_SYSusuario` AS `documentacion_SYSusuario`,`tierras`.`001_documentaciones`.`glosado_a_documentacion_id` AS `glosado_a_documentacion_id`,`tierras`.`001_documentaciones`.`glosados` AS `glosados`,`tierras`.`001_documentaciones`.`_alta_id` AS `_alta_id`,`tierras`.`001_documentaciones`.`seguimiento_id` AS `seguimiento_id`,`tierras`.`001_documentaciones`.`referencia_de_busqueda` AS `referencia_de_busqueda`,`tierras`.`001_documentaciones`.`marca_fecha` AS `marca_fecha`,`tierras`.`001_documentaciones`.`marca_hora` AS `marca_hora`,`tierras`.`001_documentaciones`.`marca_SYSusuario` AS `marca_SYSusuario`,`tierras`.`001_documentaciones`.`marca_organismo_area_id` AS `marca_organismo_area_id`,`tierras`.`001_documentaciones`.`desmarca_fecha` AS `desmarca_fecha`,`tierras`.`001_documentaciones`.`desmarca_hora` AS `desmarca_hora`,`tierras`.`001_documentaciones`.`desmarca_SYSusuario` AS `desmarca_SYSusuario`,`tierras`.`001_documentaciones`.`desmarca_organismo_area_id` AS `desmarca_organismo_area_id`,`tierras`.`001_documentaciones`.`id_formulario` AS `id_formulario` from `tierras`.`001_documentaciones` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `001_documentaciones_tipos`
--
DROP TABLE IF EXISTS `001_documentaciones_tipos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `001_documentaciones_tipos`  AS  select `tierras`.`001_documentaciones_tipos`.`documentacion_tipo_id` AS `documentacion_tipo_id`,`tierras`.`001_documentaciones_tipos`.`documentacion_tipo` AS `documentacion_tipo`,`tierras`.`001_documentaciones_tipos`.`documentacion_tipo_orden_aparicion` AS `documentacion_tipo_orden_aparicion` from `tierras`.`001_documentaciones_tipos` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_departamentos`
--
DROP TABLE IF EXISTS `_departamentos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_departamentos`  AS  select `tierras`.`_departamentos`.`departamento_id` AS `departamento_id`,`tierras`.`_departamentos`.`departamento` AS `departamento` from `tierras`.`_departamentos` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_localidades`
--
DROP TABLE IF EXISTS `_localidades`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_localidades`  AS  select `tierras`.`_localidades`.`localidad_id` AS `localidad_id`,`tierras`.`_localidades`.`departamento_id` AS `departamento_id`,`tierras`.`_localidades`.`localidad` AS `localidad` from `tierras`.`_localidades` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_organismos`
--
DROP TABLE IF EXISTS `_organismos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_organismos`  AS  select `tierras`.`_organismos`.`organismo_id` AS `organismo_id`,`tierras`.`_organismos`.`organismo` AS `organismo`,`tierras`.`_organismos`.`organismo_tipo` AS `organismo_tipo`,`tierras`.`_organismos`.`domicilio` AS `domicilio`,`tierras`.`_organismos`.`telefonos` AS `telefonos`,`tierras`.`_organismos`.`localidad_id` AS `localidad_id`,`tierras`.`_organismos`.`organismo_expediente_codigo` AS `organismo_expediente_codigo`,`tierras`.`_organismos`.`organismo_expediente_ultimonumero` AS `organismo_expediente_ultimonumero`,`tierras`.`_organismos`.`organismo_expediente_ultimoano` AS `organismo_expediente_ultimoano`,`tierras`.`_organismos`.`estado` AS `estado` from `tierras`.`_organismos` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_organismos_areas`
--
DROP TABLE IF EXISTS `_organismos_areas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_organismos_areas`  AS  select `tierras`.`_organismos_areas`.`organismo_area_id` AS `organismo_area_id`,`tierras`.`_organismos_areas`.`organismo_area_tipo_id` AS `organismo_area_tipo_id`,`tierras`.`_organismos_areas`.`organismo_area` AS `organismo_area`,`tierras`.`_organismos_areas`.`organismo_area_descripcion` AS `organismo_area_descripcion`,`tierras`.`_organismos_areas`.`organismo_id` AS `organismo_id`,`tierras`.`_organismos_areas`.`organismo_area_estado` AS `organismo_area_estado`,`tierras`.`_organismos_areas`.`organismo_area_mesa_entrada` AS `organismo_area_mesa_entrada`,`tierras`.`_organismos_areas`.`organismo_area_archivo` AS `organismo_area_archivo`,`tierras`.`_organismos_areas`.`max_dias_pendiente_recepcion` AS `max_dias_pendiente_recepcion` from `tierras`.`_organismos_areas` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_organismos_areas_usuarios`
--
DROP TABLE IF EXISTS `_organismos_areas_usuarios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_organismos_areas_usuarios`  AS  select `tierras`.`_organismos_areas_usuarios`.`organismo_area_id` AS `organismo_area_id`,`tierras`.`_organismos_areas_usuarios`.`SYSusuario` AS `SYSusuario`,`tierras`.`_organismos_areas_usuarios`.`cargo` AS `cargo` from `tierras`.`_organismos_areas_usuarios` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_sistemas_usuarios`
--
DROP TABLE IF EXISTS `_sistemas_usuarios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_sistemas_usuarios`  AS  select `tierras`.`_sistemas_usuarios`.`sistema_id` AS `sistema_id`,`tierras`.`_sistemas_usuarios`.`SYSusuario` AS `SYSusuario` from `tierras`.`_sistemas_usuarios` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_usuarios`
--
DROP TABLE IF EXISTS `_usuarios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_usuarios`  AS  select `tierras`.`_usuarios`.`SYSusuario` AS `SYSusuario`,`tierras`.`_usuarios`.`SYSpassword` AS `SYSpassword`,`tierras`.`_usuarios`.`SYSusuarionombre` AS `SYSusuarionombre`,`tierras`.`_usuarios`.`SYSusuario_sexo` AS `SYSusuario_sexo`,`tierras`.`_usuarios`.`SYSusuario_dni` AS `SYSusuario_dni`,`tierras`.`_usuarios`.`SYSusuario_cuil` AS `SYSusuario_cuil`,`tierras`.`_usuarios`.`SYSusuarioemail` AS `SYSusuarioemail`,`tierras`.`_usuarios`.`SYSusuario_comentario` AS `SYSusuario_comentario`,`tierras`.`_usuarios`.`SYSusuario_estado` AS `SYSusuario_estado` from `tierras`.`_usuarios` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `chofer`
--
ALTER TABLE `chofer`
  ADD PRIMARY KEY (`id_chofer`);

--
-- Indices de la tabla `dependencia`
--
ALTER TABLE `dependencia`
  ADD PRIMARY KEY (`id_dependencia`);

--
-- Indices de la tabla `depositario`
--
ALTER TABLE `depositario`
  ADD PRIMARY KEY (`id_depositario`);

--
-- Indices de la tabla `entsal`
--
ALTER TABLE `entsal`
  ADD PRIMARY KEY (`id_entsal`);

--
-- Indices de la tabla `incidente`
--
ALTER TABLE `incidente`
  ADD PRIMARY KEY (`id_incidente`);

--
-- Indices de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD PRIMARY KEY (`id_movimiento`);

--
-- Indices de la tabla `parque`
--
ALTER TABLE `parque`
  ADD PRIMARY KEY (`id_parque`);

--
-- Indices de la tabla `reparacion`
--
ALTER TABLE `reparacion`
  ADD PRIMARY KEY (`id_reparacion`);

--
-- Indices de la tabla `responsable`
--
ALTER TABLE `responsable`
  ADD PRIMARY KEY (`id_responsable`);

--
-- Indices de la tabla `taller`
--
ALTER TABLE `taller`
  ADD PRIMARY KEY (`id_taller`);

--
-- Indices de la tabla `tipo_incidente`
--
ALTER TABLE `tipo_incidente`
  ADD PRIMARY KEY (`id_tipo_incidente`);

--
-- Indices de la tabla `tipo_reparacion`
--
ALTER TABLE `tipo_reparacion`
  ADD PRIMARY KEY (`id_tipo_reparacion`);

--
-- Indices de la tabla `tipo_vehiculo`
--
ALTER TABLE `tipo_vehiculo`
  ADD PRIMARY KEY (`id_tipo_vehiculo`);

--
-- Indices de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD PRIMARY KEY (`id_vehiculo`);

--
-- Indices de la tabla `_auditoria`
--
ALTER TABLE `_auditoria`
  ADD PRIMARY KEY (`id_auditoria`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `chofer`
--
ALTER TABLE `chofer`
  MODIFY `id_chofer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `dependencia`
--
ALTER TABLE `dependencia`
  MODIFY `id_dependencia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT de la tabla `depositario`
--
ALTER TABLE `depositario`
  MODIFY `id_depositario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT de la tabla `entsal`
--
ALTER TABLE `entsal`
  MODIFY `id_entsal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `incidente`
--
ALTER TABLE `incidente`
  MODIFY `id_incidente` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  MODIFY `id_movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `parque`
--
ALTER TABLE `parque`
  MODIFY `id_parque` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `reparacion`
--
ALTER TABLE `reparacion`
  MODIFY `id_reparacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `responsable`
--
ALTER TABLE `responsable`
  MODIFY `id_responsable` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `taller`
--
ALTER TABLE `taller`
  MODIFY `id_taller` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `tipo_incidente`
--
ALTER TABLE `tipo_incidente`
  MODIFY `id_tipo_incidente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tipo_reparacion`
--
ALTER TABLE `tipo_reparacion`
  MODIFY `id_tipo_reparacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `tipo_vehiculo`
--
ALTER TABLE `tipo_vehiculo`
  MODIFY `id_tipo_vehiculo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  MODIFY `id_vehiculo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=191;

--
-- AUTO_INCREMENT de la tabla `_auditoria`
--
ALTER TABLE `_auditoria`
  MODIFY `id_auditoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
