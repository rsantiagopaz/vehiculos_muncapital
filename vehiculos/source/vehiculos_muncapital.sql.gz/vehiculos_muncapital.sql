-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-01-2019 a las 19:59:51
-- Versión del servidor: 10.1.31-MariaDB
-- Versión de PHP: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `vehiculos_muncapital`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chofer`
--

CREATE TABLE `chofer` (
  `id_chofer` int(11) NOT NULL,
  `apenom` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `dni` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  `email` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci,
  `telefono` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `organismo_area_id` varchar(5) COLLATE utf8_spanish_ci DEFAULT NULL,
  `licencia_oficial` enum('S','N') COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'S, N',
  `id_tipo` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `f_emision` date DEFAULT NULL,
  `f_vencimiento` date DEFAULT NULL,
  `f_inscripcion` datetime DEFAULT NULL,
  `id_parque` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dependencia`
--

CREATE TABLE `dependencia` (
  `id_dependencia` int(11) NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `depositario`
--

CREATE TABLE `depositario` (
  `id_depositario` int(11) NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entsal`
--

CREATE TABLE `entsal` (
  `id_entsal` int(11) NOT NULL,
  `id_vehiculo` int(11) DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci,
  `f_ent` datetime DEFAULT NULL,
  `id_usuario_ent` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `resp_ent` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `kilo` int(7) DEFAULT NULL,
  `cod_up` int(11) DEFAULT NULL,
  `f_sal` datetime DEFAULT NULL,
  `id_usuario_sal` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `resp_sal` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `asunto` tinyint(1) DEFAULT NULL,
  `diferido` tinyint(1) DEFAULT NULL,
  `estado` enum('E','S','T','A') COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `incidente`
--

CREATE TABLE `incidente` (
  `id_incidente` int(11) NOT NULL,
  `id_chofer` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `descrip` text COLLATE utf8_spanish_ci,
  `id_tipo_incidente` int(11) DEFAULT NULL,
  `id_usuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE `movimiento` (
  `id_movimiento` int(11) NOT NULL,
  `id_entsal` int(11) DEFAULT NULL,
  `id_taller` int(11) DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci,
  `f_ent` datetime DEFAULT NULL,
  `id_usuario_ent` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `f_sal` datetime DEFAULT NULL,
  `id_usuario_sal` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `kilo` int(7) DEFAULT NULL,
  `documentacion_id` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `estado` enum('E','S','D','A') COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'E=entrada, S=salida, D=diferido, A=anulado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parque`
--

CREATE TABLE `parque` (
  `id_parque` int(11) NOT NULL,
  `organismo_area_id` varchar(5) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `parque`
--

INSERT INTO `parque` (`id_parque`, `organismo_area_id`) VALUES
(1, 'DNBPT');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reparacion`
--

CREATE TABLE `reparacion` (
  `id_reparacion` int(11) NOT NULL,
  `id_movimiento` int(11) DEFAULT NULL,
  `id_tipo_reparacion` int(11) DEFAULT NULL,
  `costo` decimal(9,2) DEFAULT NULL,
  `cantidad` smallint(6) DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsable`
--

CREATE TABLE `responsable` (
  `id_responsable` int(11) NOT NULL,
  `apenom` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `dni` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `domicilio` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  `localidad` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cargo` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `organizacion` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `taller`
--

CREATE TABLE `taller` (
  `id_taller` int(11) NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cuit` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_incidente`
--

CREATE TABLE `tipo_incidente` (
  `id_tipo_incidente` int(11) NOT NULL,
  `descrip` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_reparacion`
--

CREATE TABLE `tipo_reparacion` (
  `id_tipo_reparacion` int(11) NOT NULL,
  `descrip` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_vehiculo`
--

CREATE TABLE `tipo_vehiculo` (
  `id_tipo_vehiculo` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculo`
--

CREATE TABLE `vehiculo` (
  `id_vehiculo` int(11) NOT NULL,
  `nro_patente` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_motor` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_tipo_vehiculo` int(11) DEFAULT NULL,
  `modelo` smallint(6) DEFAULT NULL,
  `marca` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_chasis` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `observa` mediumtext COLLATE utf8_spanish_ci,
  `nro_poliza` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `localidad_id` char(5) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_dependencia` int(11) DEFAULT NULL,
  `id_depositario` int(11) DEFAULT NULL,
  `id_responsable` int(11) DEFAULT NULL,
  `id_parque` int(11) DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `estado` enum('E','S','T') COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `_auditoria`
--

CREATE TABLE `_auditoria` (
  `id_auditoria` int(11) NOT NULL,
  `fecha` datetime DEFAULT NULL,
  `sql_texto` text COLLATE utf8_spanish_ci,
  `id` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tag` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `chofer`
--
ALTER TABLE `chofer`
  ADD PRIMARY KEY (`id_chofer`);

--
-- Indices de la tabla `dependencia`
--
ALTER TABLE `dependencia`
  ADD PRIMARY KEY (`id_dependencia`);

--
-- Indices de la tabla `depositario`
--
ALTER TABLE `depositario`
  ADD PRIMARY KEY (`id_depositario`);

--
-- Indices de la tabla `entsal`
--
ALTER TABLE `entsal`
  ADD PRIMARY KEY (`id_entsal`);

--
-- Indices de la tabla `incidente`
--
ALTER TABLE `incidente`
  ADD PRIMARY KEY (`id_incidente`);

--
-- Indices de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD PRIMARY KEY (`id_movimiento`);

--
-- Indices de la tabla `parque`
--
ALTER TABLE `parque`
  ADD PRIMARY KEY (`id_parque`);

--
-- Indices de la tabla `reparacion`
--
ALTER TABLE `reparacion`
  ADD PRIMARY KEY (`id_reparacion`);

--
-- Indices de la tabla `responsable`
--
ALTER TABLE `responsable`
  ADD PRIMARY KEY (`id_responsable`);

--
-- Indices de la tabla `taller`
--
ALTER TABLE `taller`
  ADD PRIMARY KEY (`id_taller`);

--
-- Indices de la tabla `tipo_incidente`
--
ALTER TABLE `tipo_incidente`
  ADD PRIMARY KEY (`id_tipo_incidente`);

--
-- Indices de la tabla `tipo_reparacion`
--
ALTER TABLE `tipo_reparacion`
  ADD PRIMARY KEY (`id_tipo_reparacion`);

--
-- Indices de la tabla `tipo_vehiculo`
--
ALTER TABLE `tipo_vehiculo`
  ADD PRIMARY KEY (`id_tipo_vehiculo`);

--
-- Indices de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD PRIMARY KEY (`id_vehiculo`);

--
-- Indices de la tabla `_auditoria`
--
ALTER TABLE `_auditoria`
  ADD PRIMARY KEY (`id_auditoria`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `chofer`
--
ALTER TABLE `chofer`
  MODIFY `id_chofer` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `dependencia`
--
ALTER TABLE `dependencia`
  MODIFY `id_dependencia` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `depositario`
--
ALTER TABLE `depositario`
  MODIFY `id_depositario` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `entsal`
--
ALTER TABLE `entsal`
  MODIFY `id_entsal` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `incidente`
--
ALTER TABLE `incidente`
  MODIFY `id_incidente` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  MODIFY `id_movimiento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `parque`
--
ALTER TABLE `parque`
  MODIFY `id_parque` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `reparacion`
--
ALTER TABLE `reparacion`
  MODIFY `id_reparacion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `responsable`
--
ALTER TABLE `responsable`
  MODIFY `id_responsable` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `taller`
--
ALTER TABLE `taller`
  MODIFY `id_taller` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_incidente`
--
ALTER TABLE `tipo_incidente`
  MODIFY `id_tipo_incidente` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_reparacion`
--
ALTER TABLE `tipo_reparacion`
  MODIFY `id_tipo_reparacion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_vehiculo`
--
ALTER TABLE `tipo_vehiculo`
  MODIFY `id_tipo_vehiculo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  MODIFY `id_vehiculo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `_auditoria`
--
ALTER TABLE `_auditoria`
  MODIFY `id_auditoria` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
